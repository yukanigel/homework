let visit = 0;
const vis = document.querySelector('#vis');

vis.addEventListener("click", () => {
    visit++;
    const aWord = document.createElement('p');
    aWord.textContent = `Thanks for visit № ${visit}`;
    document.body.appendChild(aWord);
});


const butn = document.querySelector('.butn');
butn.addEventListener('click', () => { document.body.classList.toggle('dark');
if (document.body.classList.contains('dark')) { butn.textContent = 'Light'; }
else { butn.textContent = 'Dark'; } });

const textField = document.getElementById('todo-input');
const createButton = document.getElementById('create-btn');
const listContainer = document.getElementById('todo-list');

createButton.addEventListener('click', () => {
const textValue = textField.value.trim();

if (textValue) {
const listItem = document.createElement('li');
listItem.textContent = textValue;
listContainer.appendChild(listItem);
textField.value = '';
}
});

listContainer.addEventListener('click', (event) => {
if (event.target.tagName === 'LI') {
    event.target.remove();
}
});

const contactForm = document.getElementById('contact-form');

        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();

            const userName = document.getElementById('fullName').value.trim();
            const userMail = document.getElementById('userEmail').value.trim();

            if (!userName || !userMail) {
                alert('Fill all up!');
                return;
            }

            if (!userMail.includes('@')) {
                alert('Weird email!');
                return;
            }

            console.log('Cool!');
        });
