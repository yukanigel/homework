//Age check
let age=0;
let status= age >18 ?"Adult" :"Kid";
console.log(status);

//list
let student=[{
    name: "Kate",
    age: 17,
    class: "11A"},
    {
    name: "Kostya",
    age: 7,
    class: "1B"},
    {
    name: "Kyoko",
    age: 19,
    class: "12"}
]

//Перебор массива
student.forEach((student)=>{
    console.log(student);
})
//Grade rate
let grade = 13;
let maxGrade = 15;
let percent = (grade*100)/maxGrade
let rate
if (percent>=85){rate="A";}
else if (percent>=65){rate="B";}
else{rate="C"}
console.log(rate)

