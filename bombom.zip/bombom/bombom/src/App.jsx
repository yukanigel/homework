import { useState, useEffect } from "react";

function App() {
  

  return (
    <>
      <Header name="Kate" avatar="/photo4.jpg" avatarname="My avatar"/>
      <TodoApp/>
    </>
  )
};


//Functions

function Header(props){
  return(
    <div className="headHeader">
      <div className="header">
        <h1>{props.name}</h1>
        <img src={props.avatar} alt={props.avatarname}></img>
      </div>
    </div>
  );
} 

function TodoApp(){
  
  //task to add

  const [taskToAdd, setTask] = useState('');
  const [cat, setList] = useState([]);
  const splinter = '+!-+';
  
  function ListStringConv (listName){
    let moon = '';
    listName.map((tick)=> moon = moon+splinter+tick);
    return moon
    };

  function StringListConv (stringName){
    let star = [];
    star = stringName.split('+!-+');
    return star;
    };

  useEffect(() => {
    const prevCat = localStorage.getItem('ToDoList');
    if (prevCat) {
      const gottenCat = StringListConv(prevCat);
      setList(gottenCat.filter((kitty) => kitty.trim() !== ''));
    }}, []
  );

  useEffect(()=>{
    let sun = ListStringConv(cat);
    localStorage.setItem('ToDoList', sun);
    }, [cat]
  );

  //html part
  return(
    <>
      <div className="TodoApp">    
        <h2>To-Do List</h2>
        <div className="TodoParts">
          <div className="formField">
            <input
            placeholder="Your task"
            value={taskToAdd}
            onChange={(e)=> setTask(e.target.value)}
            >
            </input>
            <button onClick={()=>{
              if (taskToAdd.trim() !== ''){
                const newCat = [...cat, taskToAdd];
                setList(newCat);
                setTask('');
            }
            }}>
              Add
            </button>
          </div>
          <div className="taskList">
            {
              cat.map(
                (pony, index)=>{
                  return(
                    <div className="oneTaskDiv">
                      <input type="checkbox"></input>
                      <div className="taskValueField">
                        <p className="aTask">{pony}</p>
                        <button className="DeleteButton"
                          onClick={() =>{
                            setList(cat.filter(
                            (bate, tame)=> tame!==index
                            ));
                          }}
                        >X</button>
                      </div>
                    </div>
                  )
                }
              )
            } 
          </div>
        </div>
      </div>
    </>
  )
}

export default App